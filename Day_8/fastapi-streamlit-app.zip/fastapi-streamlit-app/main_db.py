from fastapi import FastAPI, HTTPException, Depends
from sqlalchemy.orm import Session

import models
import schemas

from database import engine, SessionLocal

# Create the SQLite table if it doesn't exist
models.Base.metadata.create_all(bind=engine)

app = FastAPI()


# Dependency to get a database session
def get_db():

    db = SessionLocal()

    try:
        yield db

    finally:
        db.close()


# ----------------------------
# CREATE
# ----------------------------
@app.post("/todos/", response_model=schemas.Todo)
def create_todo(todo: schemas.Todo,
                db: Session = Depends(get_db)):

    # Check if ID already exists
    existing = db.query(models.Todo).filter(
        models.Todo.id == todo.id
    ).first()

    if existing:
        raise HTTPException(
            status_code=400,
            detail="To-do item already exists"
        )

    db_todo = models.Todo(
        id=todo.id,
        title=todo.title,
        description=todo.description
    )

    db.add(db_todo)

    db.commit()

    db.refresh(db_todo)

    return db_todo


# ----------------------------
# READ
# ----------------------------
@app.get("/todos/{todo_id}",
         response_model=schemas.Todo)
def read_todo(todo_id: int,
              db: Session = Depends(get_db)):

    todo = db.query(models.Todo).filter(
        models.Todo.id == todo_id
    ).first()

    if not todo:
        raise HTTPException(
            status_code=404,
            detail="To-do item not found"
        )

    return todo


# ----------------------------
# UPDATE
# ----------------------------
@app.put("/todos/{todo_id}",
         response_model=schemas.Todo)
def update_todo(todo_id: int,
                todo_item: schemas.Todo,
                db: Session = Depends(get_db)):

    todo = db.query(models.Todo).filter(
        models.Todo.id == todo_id
    ).first()

    if not todo:
        raise HTTPException(
            status_code=404,
            detail="To-do item not found"
        )

    todo.title = todo_item.title
    todo.description = todo_item.description

    db.commit()

    db.refresh(todo)

    return todo


# ----------------------------
# DELETE
# ----------------------------
@app.delete("/todos/{todo_id}")
def delete_todo(todo_id: int,
                db: Session = Depends(get_db)):

    todo = db.query(models.Todo).filter(
        models.Todo.id == todo_id
    ).first()

    if not todo:
        raise HTTPException(
            status_code=404,
            detail="To-do item not found"
        )

    db.delete(todo)

    db.commit()

    return {"detail": "To-do item deleted"}