import os, streamlit as st
from dotenv import load_dotenv
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_chroma import Chroma
from agents.retrieval_agent import set_retriever
from graph import build_graph

load_dotenv()
os.environ['OPENAI_API_KEY']=os.getenv('OPENAI_API_KEY')

st.title('LangGraph RAG V1')
pdf=st.file_uploader('Upload PDF',type='pdf')
if pdf:
    open(pdf.name,'wb').write(pdf.getbuffer())
    docs=PyPDFLoader(pdf.name).load()
    chunks=RecursiveCharacterTextSplitter(chunk_size=500,chunk_overlap=100).split_documents(docs)
    vs=Chroma.from_documents(chunks,OpenAIEmbeddings(model='text-embedding-3-small'))
    set_retriever(vs.as_retriever(search_kwargs={'k':3}))
    graph=build_graph()
    q=st.text_input('Question')
    if q:
        result=graph.invoke({'question':q,'documents':[],'answer':''})
        st.write('Rewritten Question:',result['question'])
        st.write('Retrieved Chunks:',len(result['documents']))
        st.subheader('Answer')
        st.write(result['answer'])
