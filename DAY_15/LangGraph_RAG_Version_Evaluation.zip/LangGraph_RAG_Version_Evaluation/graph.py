from langgraph.graph import StateGraph, END

from state import AgentState

from agents.query_agent import query_agent
from agents.retrieval_agent import retrieval_agent
from agents.answer_agent import answer_agent
from agents.evaluation_agent import evaluation_agent


def build_graph():

    builder = StateGraph(AgentState)

    builder.add_node(
        "query",
        query_agent,
    )

    builder.add_node(
        "retrieve",
        retrieval_agent,
    )

    builder.add_node(
        "answer",
        answer_agent,
    )

    builder.add_node(
        "evaluate",
        evaluation_agent,
    )

    builder.set_entry_point("query")

    builder.add_edge(
        "query",
        "retrieve",
    )

    builder.add_edge(
        "retrieve",
        "answer",
    )

    builder.add_edge(
        "answer",
        "evaluate",
    )

    builder.add_edge(
        "evaluate",
        END,
    )

    return builder.compile()