from langgraph.graph import StateGraph, END
from state import AgentState
from agents.query_agent import query_agent
from agents.retrieval_agent import retrieval_agent
from agents.answer_agent import answer_agent
def build_graph():
    g=StateGraph(AgentState)
    g.add_node('query',query_agent)
    g.add_node('retrieve',retrieval_agent)
    g.add_node('answer',answer_agent)
    g.set_entry_point('query')
    g.add_edge('query','retrieve')
    g.add_edge('retrieve','answer')
    g.add_edge('answer',END)
    return g.compile()
