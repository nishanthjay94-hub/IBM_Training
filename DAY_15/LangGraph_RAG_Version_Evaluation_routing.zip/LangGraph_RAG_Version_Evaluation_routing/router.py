def route_after_evaluation(state):

    score = state["evaluation"]["faithfulness"]

    if score >= 0.8:
        return "good"

    if state["retry_count"] >= 2:
        return "good"

    state["retry_count"] += 1

    return "retry"