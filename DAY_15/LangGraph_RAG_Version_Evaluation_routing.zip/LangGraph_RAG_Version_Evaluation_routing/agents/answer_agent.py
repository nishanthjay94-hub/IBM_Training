from langchain_openai import ChatOpenAI

llm = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0
)

def answer_agent(state):

    context = "\n\n".join(
        doc.page_content
        for doc in state["documents"]
    )

    prompt = f"""
Answer using ONLY the context.

Context:

{context}

Question:

{state["question"]}
"""

    response = llm.invoke(prompt)

    state["answer"] = response.content

    return state