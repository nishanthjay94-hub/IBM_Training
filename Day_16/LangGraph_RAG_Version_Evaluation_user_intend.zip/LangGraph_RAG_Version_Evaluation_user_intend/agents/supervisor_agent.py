from typing import Literal

from pydantic import BaseModel

from langchain_openai import ChatOpenAI


# -----------------------------
# Structured Output Schema
# -----------------------------
class Route(BaseModel):

    route: Literal[
        "rag",
        "weather",
        "search"
    ]


# -----------------------------
# LLM
# -----------------------------
llm = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0
)


# Force the LLM to return the Route schema
router = llm.with_structured_output(Route)


# -----------------------------
# Supervisor Agent
# -----------------------------
def supervisor_agent(state):

    prompt = f"""
You are an AI Supervisor.

Your responsibility is to decide
which agent should answer the user's question.

Available Agents:

1. rag
   - Questions about uploaded PDF documents
   - Company policies
   - HR manuals
   - User uploaded knowledge base

2. weather
   - Weather
   - Temperature
   - Rain
   - Forecast
   - Climate
   - Humidity

3. search
   - Latest news
   - Recent events
   - Internet search
   - Current affairs
   - Live information

Rules:

Return ONLY ONE route.

Question:

{state["question"]}
"""

    result = router.invoke(prompt)

    state["route"] = result.route

    return state