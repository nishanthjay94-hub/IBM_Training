from langchain_openai import ChatOpenAI

llm = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0
)


def answer_agent(state):
    """
    Generate the final response.
    """

    route = state["route"]

    # -----------------------------
    # RAG Route
    # -----------------------------
    if route == "rag":

        context = "\n\n".join(
            doc.page_content
            for doc in state["documents"]
        )

        prompt = f"""
Answer ONLY using the context below.

Context:

{context}

Question:

{state["question"]}
"""

    # -----------------------------
    # Weather Route
    # -----------------------------
    elif route == "weather":

        prompt = f"""
The following weather information
was returned by a weather API.

{state["tool_output"]}

Present it in a friendly way.
"""

    # -----------------------------
    # Search Route
    # -----------------------------
    else:

        prompt = f"""
The following information
was returned from an Internet search.

{state["tool_output"]}

Summarize it clearly.
"""

    response = llm.invoke(prompt)

    state["answer"] = response.content

    return state