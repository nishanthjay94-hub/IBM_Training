vectorstore = None


def set_vectorstore(vs):
    global vectorstore
    vectorstore = vs


def retrieval_agent(state):

    # Increase k on every retry
    k = 3 + (state["retry_count"] * 3)

    retriever = vectorstore.as_retriever(
        search_kwargs={"k": k}
    )

    documents = retriever.invoke(
        state["question"]
    )

    state["documents"] = documents

    return state
