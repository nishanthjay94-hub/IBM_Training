from langchain_openai import ChatOpenAI

llm = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0
)

def query_agent(state):

    question = state["question"]

    prompt = f"""
Rewrite this question to improve document retrieval.

Question:
{question}
"""

    rewritten = llm.invoke(prompt)

    state["question"] = rewritten.content

    return state