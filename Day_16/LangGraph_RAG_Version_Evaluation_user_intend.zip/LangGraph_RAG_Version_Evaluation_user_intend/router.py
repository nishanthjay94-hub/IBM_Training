"""
router.py

This file contains all the routing logic used by LangGraph.

There are two routers:

1. route_question()
   - Reads the Supervisor Agent's decision.
   - Chooses which agent should execute next.

2. retry_or_end()
   - Checks the RAG evaluation score.
   - Decides whether to retry retrieval or end the graph.
"""


def route_question(state):
    """
    Read the route selected by the Supervisor Agent.

    Possible values:
        - rag
        - weather
        - search
    """

    return state["route"]


def retry_or_end(state):
    """
    Decide whether to retry retrieval or finish.

    Rules:
    1. Weather/Search never retry.
    2. RAG retries if Faithfulness < 0.80.
    """

    # ------------------------------------
    # Weather & Search do not require RAG evaluation
    # ------------------------------------
    if state["route"] != "rag":
        return "end"

    # ------------------------------------
    # If evaluation is somehow missing,
    # safely end instead of crashing.
    # ------------------------------------
    if not state["evaluation"]:
        return "end"

    # ------------------------------------
    # Read Faithfulness Score
    # ------------------------------------
    faithfulness = state["evaluation"].get(
        "faithfulness",
        1.0
    )

    # ------------------------------------
    # Retry if score is poor
    # ------------------------------------
    if faithfulness < 0.80:

        # Increase retry counter
        state["retry_count"] += 1

        # Maximum two retries
        if state["retry_count"] <= 2:
            return "retry"

    # ------------------------------------
    # Otherwise stop
    # ------------------------------------
    return "end"