from langgraph.graph import StateGraph, END

from state import AgentState

# Routers
from router import (
    route_question,
    retry_or_end
)

# Agents
from agents.supervisor_agent import supervisor_agent
from agents.retrieval_agent import retrieval_agent
from agents.answer_agent import answer_agent
from agents.weather_agent import weather_agent
from agents.search_agent import search_agent
from agents.evaluation_agent import evaluation_agent


def build_graph():

    # ------------------------------------
    # Create Graph
    # ------------------------------------
    builder = StateGraph(AgentState)

    # ------------------------------------
    # Add Nodes
    # ------------------------------------
    builder.add_node(
        "supervisor",
        supervisor_agent
    )

    builder.add_node(
        "retrieve",
        retrieval_agent
    )

    builder.add_node(
        "weather",
        weather_agent
    )

    builder.add_node(
        "search",
        search_agent
    )

    builder.add_node(
        "answer",
        answer_agent
    )

    builder.add_node(
        "evaluation",
        evaluation_agent
    )

    # ------------------------------------
    # Entry Point
    # ------------------------------------
    builder.set_entry_point(
        "supervisor"
    )

    # ------------------------------------
    # Supervisor decides
    # which node to execute
    # ------------------------------------
    builder.add_conditional_edges(
        "supervisor",
        route_question,
        {
            "rag": "retrieve",
            "weather": "weather",
            "search": "search"
        }
    )

    # ------------------------------------
    # RAG Flow
    # ------------------------------------
    builder.add_edge(
        "retrieve",
        "answer"
    )

    # ------------------------------------
    # Weather Flow
    # ------------------------------------
    builder.add_edge(
        "weather",
        "answer"
    )

    # ------------------------------------
    # Search Flow
    # ------------------------------------
    builder.add_edge(
        "search",
        "answer"
    )

    # ------------------------------------
    # Every answer goes for evaluation
    # ------------------------------------
    builder.add_edge(
        "answer",
        "evaluation"
    )

    # ------------------------------------
    # Evaluation decides whether to retry
    # ------------------------------------
    builder.add_conditional_edges(
        "evaluation",
        retry_or_end,
        {
            "retry": "retrieve",
            "end": END
        }
    )

    # ------------------------------------
    # Compile Graph
    # ------------------------------------
    graph = builder.compile()

    return graph